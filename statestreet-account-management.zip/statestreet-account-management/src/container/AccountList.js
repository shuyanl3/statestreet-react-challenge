import React, {Component} from 'react';
import * as transactionAction from "../redux/module/transaction"
import {bindActionCreators} from 'redux';
import {connect} from "react-redux";
import AccountListTable from '../component/AccountListTable'
import Filters from '../component/Filters';

class AccountList extends Component {

    componentDidMount() {
        this.props.getTransaction()
    }

    handleAccountNameSelect = () => {
    }
  
    render() {
        console.log(this.props)
      return (
        <React.Fragment>
          <Filters handleAccountNameSelect={this.handleAccountNameSelect}/>
          <AccountListTable accountsData={this.props.transaction}/>
        </React.Fragment>
      )
    }
  }

const mapStateToProps = (state) => {
    return {
      transaction: state.transaction,
      accountNameFilter: state.accountNameFilter,
      transactionTypeFilter: state.transactionTypeFilter
    };
  }
  
  const mapDispatchToProps = (dispatch) => ({
    ...bindActionCreators({
      ...transactionAction
    }, dispatch),
  });
  
  export default connect(mapStateToProps, mapDispatchToProps)(AccountList);
  