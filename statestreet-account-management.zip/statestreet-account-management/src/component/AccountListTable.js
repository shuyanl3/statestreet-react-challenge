import React from 'react';
import PropTypes from 'prop-types';

const AccountListTable = props => {
        return (
            <table>
                <tbody>
                    <tr>
                        <td>ACCOUNT NO.</td>
                        <td>ACCOUNT NAME</td>
                        <td>CURRENCY</td>
                        <td>AMOUNT</td>
                        <td>TRASACTION TYPE</td>
                    </tr>
                    {
                        props.accountsData?.transactions?.map((item, index) => (
                            <tr key={index}>
                                <td>{item.account}</td>
                                <td>{item.accountName}</td>
                                <td>{item.currencyCode}</td>
                                <td>{item.amount}</td>
                                <td>{item.transactionType}</td>
                            </tr>
                        ))
                    }
                </tbody>
            </table>
    );
}

AccountListTable.propTypes = {
    accountsData: PropTypes.object
}


export default AccountListTable;