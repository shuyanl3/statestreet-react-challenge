import React from 'react';

const CheckBox = props => {
    return (
        <div>
            <label>
                <input type="checkbox" onChange={props.handleChange}/>
                <span>{props.label}</span>
            </label>
        </div>
    );
};

export default CheckBox;