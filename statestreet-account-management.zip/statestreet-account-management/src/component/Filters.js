import React from 'react';
import CheckBox from './CheckBox';

const Filters = props => {
        return (
            <div>
                <CheckBox 
                    label="Savings Account"
                    handleChange={props.handleAccountNameSelect}
                />
                <CheckBox 
                    label="Checking Account"
                    handleChange={props.handleAccountNameSelect}
                />
                <CheckBox 
                    label="Auto Loan Account"
                    handleChange={props.handleAccountNameSelect}
                />
                <CheckBox 
                    label="Credit Card Account"
                    handleChange={props.handleAccountNameSelect}
                />
                {/* <CheckBox 
                     label="Investment Account"
                     handleChange={props.handleAccountNameSelect}
                />
                <CheckBox 
                    label="Personal Loan Account"
                    handleChange={props.handleAccountNameSelect}
                />
                <CheckBox 
                    label="Money Market Account"
                    handleChange={props.handleAccountNameSelect}
                />
                <CheckBox 
                    label="Home Loan Account"
                    handleChange={props.handleAccountNameSelect}
                /> */}
            </div>
        );
}

export default Filters;