import {transactionQuery} from '../../service/transaction'
/**
 * name the type as the URL is one of the typical way of naming
 */
const GETTRANS = "xxx"
const ERROR = "yyy"


/**
 * get transaction action creator
 */
function getTransactionActionCreator() {
    return {
        type: GETTRANS,
        payload: {transactions: "default"}
    }
}

function error() {
    return {
        type: ERROR,
        payload: "Something Went Wrong. Please try again"
    }
}

/**
 * Action
 */
export function getTransaction() {
    return (dispatch, getState) => {
        try {
            //get data
            dispatch(getTransactionActionCreator())
        }
        catch {
            dispatch(error())
        }
    }
}

/**
 * transaction reducer
 */
function transactionRedcer(state = {accountNameFilter: [], transactionTypeFilter: []}, action) {
    switch (action.type) {
        case GETTRANS:
            action.payload.transactions = transactionQuery.transactions.filter(
                item => (state.accountNameFilter?.includes(item.accountName) || !state.accountNameFilter)
                && (state.transactionTypeFilter?.includes(item.transactionType) || !state.transactionType)
            )
            return action.payload
        default:
            return {data: {}}
    }
}

export default transactionRedcer